
public class Driver {
	public static void main(String[] args) {
		Doctor d = new Doctor();
		Doctor d2 = new Doctor();
		System.out.println(Doctor.getCountOfDoctors());
	}
}
