
public class Doctor {
	
	private String name;
	private String speciality;
	private int yearsOfExperience;
	private StringBuffer patientsSeen;
	private static int count;
	
	public Doctor(String name, String speciality, int yearsOfExperience) {
		this.name = name;
		this.speciality = speciality;
		if(isValidYears(yearsOfExperience)) {
			this.yearsOfExperience = yearsOfExperience;
		}
		else {
			this.yearsOfExperience = 0;
		}
		patientsSeen = new StringBuffer("");
		count++;
	}
	
	public Doctor(String name, String speciality) {
		this.name = name;
		this.speciality = speciality;
		if(isValidYears(yearsOfExperience)) {
			this.yearsOfExperience = yearsOfExperience;
		}
		else {
			this.yearsOfExperience = 0;
		}
		patientsSeen = new StringBuffer("");
		count++;
//		this(name, speciality, 0); (Equivalent to this)
	}
	
	public Doctor() {
		this(null, null);
	}
	
	public Doctor(Doctor d) {
		this(d.name, d.speciality, d.yearsOfExperience);
		this.patientsSeen = new StringBuffer(d.patientsSeen);
	}
	
	public String toString() {
		return "Name: " + name + " Speciality: " + speciality + " yearsOfExperience: "
				+ yearsOfExperience + " patientsSeen: " + patientsSeen;
	}
	
	public void seePatient(String name) {
		patientsSeen.append(name);
	}
	
	public Doctor increaseExperience(int years) {
		if(isValidYears(years)) {
			yearsOfExperience += years;
		}
		return this;
	}
	
	public String getSpeciality() {
		return speciality;
	}
	
	public void setSpeciality(String newSpeciality) {
		this.speciality = newSpeciality;
	}
	
	private boolean isValidYears(int yearsToAdd) {
		if(yearsToAdd >= 0 && yearsToAdd <= 75) {
			return true;
		}
		return false;
	}
	
	public static int getCountOfDoctors() {
		return count;
	}
	
	
}
