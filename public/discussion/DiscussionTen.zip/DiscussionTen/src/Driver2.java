
public class Driver2 {
	public static void main(String[] args) {
		Building aptTwo = new Building("aptTwo", 6);
		Building restaurant = new Building("Stamp");
		
		System.out.println(restaurant);
		System.out.println(aptTwo);
	}
}
