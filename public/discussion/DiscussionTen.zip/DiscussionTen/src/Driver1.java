
public class Driver1 {
	public static void main(String[] args) {
			
		
		Building aptOne = new Building();
		aptOne.init("aptOne", 4);
		
		int floors = aptOne.getNumberOfFloors();
		floors = floors * 3 + 1;
		String s = aptOne.getName();
		
		aptOne.printBuildingInfo();
	
	}
}
