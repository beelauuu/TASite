
public class Building {
		private String nameOfBuilding;
		private int numberOfFloors;
		private static int numberOfBuildingWeHave = 0;
		
		
		  public Building(String buildingName, int numberOfFloors) {
		  this.numberOfFloors = numberOfFloors; 
		  nameOfBuilding = buildingName;
		  numberOfBuildingWeHave++; 
		  }
		  
		  public Building(String buildingName) {
		  this.numberOfFloors = 1; 
		  nameOfBuilding = buildingName;
		  numberOfBuildingWeHave++; 
		  }
		  
		  public Building(int numberOfFloors) {
		  this.numberOfFloors = numberOfFloors; 
		  nameOfBuilding = "DEFAULT";
		  numberOfBuildingWeHave++; 
		  }
		 
		
////		Pretty much equivalent to constructor
//		public void init(String buildingName, int numberOfFloors) {
//			this.numberOfFloors = numberOfFloors;
//			nameOfBuilding = buildingName;
//			numberOfBuildingWeHave++;
//		}
		
//		Getters
		public String getName() {
			return nameOfBuilding;
		}
		
		public int getNumberOfFloors() {
			return numberOfFloors;
		}
		public static int getNumberOfBuildings() {
			return numberOfBuildingWeHave;
		}
		
//		Setters
		public void setName(String newName) {
			nameOfBuilding = newName;
		}
		
		public void setNumberOfFloors(int numberOfFloors) {
			this.numberOfFloors = numberOfFloors;
		}
		
		public void printBuildingInfo() {
			System.out.println("The name of this building is: " + nameOfBuilding);
			System.out.println("The number of floors is: " + numberOfFloors);
		}
		
		public String toString() {
			return "Name: " + nameOfBuilding + " " + "Number Of Floors: " + numberOfFloors;
		}
		
		
}
