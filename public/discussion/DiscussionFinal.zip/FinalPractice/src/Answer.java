import java.util.ArrayList;
import java.util.Collections;

public class Answer {
	public static ArrayList<Integer> findValidSums(int[][] array) {
        if (array == null) {
            return null;
        }

        ArrayList<Integer> sums = new ArrayList<>();
        for (int[] row : array) {
            if (row == null) {
                sums.add(null);
            } else {
                int rowSum = 0;
                boolean hasNull = false;
                for (Integer num : row) {
                    if (num == null) {
                        hasNull = true;
                        break;
                    }
                    rowSum += num;
                }
                sums.add(hasNull ? -1 : rowSum);
            }
        }
        Collections.sort(sums);
        return sums;
    }
	
	public static int setToPositive(int[] array) {
        return setToPositive(array, 0);
    }

    
    /*
     * Base case: index out of bounds
     */
    private static int setToPositive(int[] array, int index) {
        if(index < 0 || index >= array.length) {
        	return 0;
        }
        
        if(array[index] < 0) {
        	array[index] = -1 * array[index];
        	return 1 + setToPositive(array, index + 1);
        }
        
        return setToPositive(array, index + 1);
    }
    
    public void removeDups(ArrayList<Integer> arr) {
        removeDups(arr, 0);
	}
    
    private void removeDups(ArrayList<Integer> arr, int index) {
        if(index < 0 || index + 1 >= arr.size()) {
        	return;
        } else {
        	if(arr.get(index) == arr.get(index + 1)) {
        		arr.remove(index);
        		removeDups(arr, index);
        	} else {
        		removeDups(arr, index + 1);
        	}
        }
        
    }
}
