import java.util.ArrayList;

public class Duplicates {
		/**
		 * Remove any consecutive duplicate values in the arraylist (recursively :))
		 * You can use a helper
		 * Ex. [1, 2, 3, 3, 4, 4, 5] -> [1, 2, 3, 4, 5]
		 * 
		 */
	
	public void removeDups(ArrayList<Integer> arr) {
	}
	
}
