import java.util.ArrayList;
import java.util.Arrays;

public class ClassPractice {
	/*
	 * 1. Create an interface called Shape with the following methods:
    	    double getArea();
    	    double getPerimeter();
	   2. Create a class called Rectangle that represents a rectangle shape and implements the Shape interface. 
	   The class should have the following features:
			a. Instance variables:
			   width (double) - represents the width of the rectangle.
			   height (double) - represents the height of the rectangle.
			b. Constructor:
			   Rectangle(double width, double height) - constructs a rectangle with the given width and height.
			   Rectangle(double width) - similar to above, but set height to default value of 5
			c. Methods:
			   a. Implement the methods from the Shape interface to calculate the area 
			   and perimeter of the rectangle based on its width and height.
			   b. Create a static method findLargestRectangle(Rectangle[] rectangles) 
			   that takes an array of Rectangle objects and returns the rectangle with the largest area.
			   c. Create a static method findLargestRectangle(ArrayList<Rectangle> rectangles)
			    that takes an ArrayList of Rectangle objects 
			   and returns the rectangle with the largest area.
	 */
	
	public static void main(String[] args) {
	    // Create an array of Rectangle objects
	    Rectangle[] rectangleArray = {
	        new Rectangle(4, 5),
	        new Rectangle(3, 8),
	        new Rectangle(2, 10),
	        new Rectangle(7, 4)
	    };

	    // Find the largest rectangle from the array
	    Rectangle largestRectFromArray = Rectangle.findLargestRectangle(rectangleArray);
	    System.out.println("Largest rectangle (from array): " + largestRectFromArray.getWidth() + " x " + largestRectFromArray.getHeight()); 
	    // Expected output: Largest rectangle (from array): 7.0 x 4.0

	    // Create an ArrayList of Rectangle objects
	    ArrayList<Rectangle> rectangleList = new ArrayList<>(Arrays.asList(
	        new Rectangle(7, 2),
	        new Rectangle(6, 9),
	        new Rectangle(5, 3),
	        new Rectangle(4, 11)
	    ));

	    // Find the largest rectangle from the ArrayList
	    Rectangle largestRectFromList = Rectangle.findLargestRectangle(rectangleList);
	    System.out.println("Largest rectangle (from ArrayList): " + largestRectFromList.getWidth() + " x " + largestRectFromList.getHeight()); 
	    // Expected output: Largest rectangle (from ArrayList): 6.0 x 9.0
	}


}
