
public class BePositive {
	/*
     * Modify the elements of the array RECURSIVELY so that all negative values are
     * positive. (You can use a helper :) )
     * 
     * Returns the number of values flipped
     */
    public static int setToPositive(int[] array) {
    	return 0;
    }
}
