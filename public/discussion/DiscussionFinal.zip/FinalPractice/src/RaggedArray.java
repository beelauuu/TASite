import java.util.ArrayList;

public class RaggedArray {

	/*
	 * Given a ragged 2d array of Integers.
	 * You must traverse the array and find the sum of each row and add that sum to the ArrayList that you will return.
	 * The sums must be added to the ArrayList in ascending order (0,1,...,n-1)
	 * If the row has a length of 0 the sum is 0.
	 * If any of the individual entries in the 2d array are null you must add -1 to the ArrayList for that row.
	 * If any of the rows in the 2d array are null you must add null to the ArrayList for that row
	 * If the 2d array is null you must return null
	 * 
	 */

	public static ArrayList<Integer> findValidSums(Integer [][] array) {
	    return null;
	}
}
