//Brian's overview of the final!: just a brief overview, you should study more :)
//In order to get everything in here, I wrote everything in comments, I encourage you
//to actually take the code examples and run them yourself
//Use 'Ctrl -' and 'Ctrl +' to zoom in and out to view all my comments if you need.

//Object-Oriented Terminology
/*Java is an object-oriented programming language and it uses a lot of object-oriented terminology.
 *Here are some examples:
 *Class - A blueprint for creating objects.
 *Object - An instance of a class.
 *Inheritance - A mechanism for creating a new class from an existing class.
 *Polymorphism - The ability of an object to take many forms.
 *Encapsulation - The practice of keeping an object's state private and hiding implementation details.
 *Abstraction - The process of hiding implementation details and providing a simplified interface to the user.
 *Interface - A collection of abstract methods that a class can implement.
*/

//Java Variables and Types (Primitives)
/*
 * Java has several built-in data types, including 
 * integers, floating-point numbers, characters, and booleans. 
 * Here's an example that demonstrates some of these types:
 * 
 * public class Main {
    public static void main(String[] args) {
        int age = 42;
        double weight = 185.5;
        char initial = 'J';
        boolean isMarried = true;
        
        System.out.println("Age: " + age); 42
        System.out.println("Weight: " + weight); 185.5
        System.out.println("Initial: " + initial); J
        System.out.println("Married: " + isMarried); true
    }
}
*/

//Expressions and Side Effects
/*
 * An expression is a combination of variables, operators, and method calls that evaluates to a value. 
 * In Java, expressions can have side effects, which means that they can change the state of the program 
 * or have an impact outside of the expression itself. The most notable case of this would be when using
 * ++ or -- operators
 * 
 * public class Main {
    public static void main(String[] args) {
        // initialize x to 10
        int x = 10;
        // initialize y to 20
        int y = 20;
        
        // compute z as the sum of x and y, where x is post-incremented and y is pre-incremented
        int z = x++ + ++y;
        // x should now be 11 (post-incremented)
        // y should now be 21 (pre-incremented)
        // z should be the sum of the original values of x and y, which is 10 + 21 = 31
        
        // print the value of x to the console
        System.out.println("x: " + x);
        // this should output "x: 11"
        
        // print the value of y to the console
        System.out.println("y: " + y);
        // this should output "y: 21"
        
        // print the value of z to the console
        System.out.println("z: " + z);
        // this should output "z: 31"
    }
}
*/

//Java Numeric/String/Logical Operators
/*
 * Java provides a variety of operators for 
 * performing arithmetic, string manipulation, and logical operations. 
 * Here are some examples:
 * 
 * public class Main {
    public static void main(String[] args) {
        // Arithmetic operators
        int x = 10;
        int y = 3;
        
        System.out.println("x + y = " + (x + y)); // 13
        System.out.println("x - y = " + (x - y)); // 7
        System.out.println("x * y = " + (x * y)); // 30
        System.out.println("x / y = " + (x / y)); // 3
        System.out.println("x % y = " + (x % y)); // 1
        
        // String operators
        String name = "Alice";
        String greeting = "Hello, " + name + "!";
        
        System.out.println(greeting); // "Hello, Alice!"
        
        // Logical operators
        boolean a = true;
        boolean b = false;
        
        System.out.println("a && b = " + (a && b)); // false
        System.out.println("a || b = " + (a || b)); // true
        System.out.println("!a = " + (!a)); // false
    }
}
*/

//Assignment Operators
/*
 * Java provides several assignment operators for setting the value of a variable. Here's an example:
 * public class Main {
    public static void main(String[] args) {
        int x = 10;
        
        x += 5; // equivalent to x = x + 5;
        System.out.println("x = " + x); // 15
        
        x -= 3; // equivalent to x = x - 3;
        System.out.println("x = " + x); // 12
        
        x *= 2; // equivalent to x = x * 2;
        System.out.println("x = " + x); // 24
        
        x /= 3; // equivalent to x = x / 3;
        System.out.println("x = " + x); // 8
        
        x %= 2; // equivalent to x = x % 2;
        System.out.println("x = " + x); // 0
    }
}
*/

//Short Circuiting
/*
 * Java's logical operators (&& and ||) have a short-circuiting behavior, 
 * which means that they can avoid evaluating their second operand 
 * if the result can be determined from the first operand. Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        int x = 10;
        int y = 0;
        
        if (y != 0 && x / y > 5) {
            System.out.println("This won't be printed");
        }
        
        if (y == 0 || x / y > 5) {
            System.out.println("This will be printed");
        }
    }
}
 * How is this an example of short-circuiting?
*/

//Scanner Class
/*
 * The Scanner class is used for reading input from the user or from a file. 
 * Here's an example of how to use it to read an integer from the user:
 * 
	import java.util.Scanner;

	public class Main {
    	public static void main(String[] args) {
        	Scanner scanner = new Scanner(System.in);
        
        	System.out.print("Enter an integer: ");
        	int x = scanner.nextInt();
        
        	System.out.println("You entered: " + x);
    	}
	} 
*/

//System.out.println()
/* The System.out.println() method is used to print output to the console. Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        int x = 10;
        System.out.println("The value of x is " + x);
    }
}
*/

//Conditional Statements
/*
 * Java provides several conditional statements for executing code 
 * based on a boolean condition. Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        int x = 10;
        
        if (x > 5) {
            System.out.println("x is greater than 5");
        } 
        else if (x < 3) {
        	System.out.println("x is less than 3");
        }
        else {
            System.out.println("x is less than or equal to 5");
        }
    }
}
*/

//Blocks and Scoping
/*
 * In Java, a block is a group of statements enclosed in curly braces {}. 
 * Variables declared inside a block are only visible within that block and its sub-blocks. 
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        int x = 10;
        
        for(int i = 0; i < 10; i++) {
        	System.out.println("Hi mom!");
        }
        
        // This won't compile because i is not in scope
        // System.out.println("i = " + i);
    }
}
*/

//Constants
/*
 * In Java, constants are variables whose value cannot be changed after they are initialized. 
 * Here's an example:
 * 
 * public class Main {
    public static final int MY_CONSTANT = 42;
    
    public static void main(String[] args) {
        System.out.println("The value of MY_CONSTANT is " + MY_CONSTANT);
    }
}
 * Notice the final keyword.
*/

//Loops (whiles, do whiles, for loops)
/*
 * Java provides several types of loops for iterating over a block of code multiple times. 
 * Here are some examples:
 * 
while loop:

public class Main {
    public static void main(String[] args) {
        int x = 0;
        
        while (x < 10) {
            System.out.println("x = " + x);
            x++;
        }
    }
}
In this example, we use a while loop to print out the values of x from 0 to 9.

do-while loop:

public class Main {
    public static void main(String[] args) {
        int x = 0;
        
        do {
            System.out.println("x = " + x);
            x++;
        } while (x < 10);
    }
}
In this example, we use a do-while loop to print out the values of x from 0 to 9. 
The difference between a do-while loop and a while loop is that a do-while loop 
always executes the block of code at least once, even if the condition is false.

for loop:

public class Main {
    public static void main(String[] args) {
        for (int x = 0; x < 10; x++) {
            System.out.println("x = " + x);
        }
    }
}
In this example, we use a for loop to print out the values of x from 0 to 9. 
The for loop has three parts: the initialization (int x = 0), 
the condition (x < 10), and the update (x++).
*/

//Static methods
/*
 * Static methods are methods that belong to a class rather than an instance of the class. 
 * Here's an example:

public class Main {
    public static void main(String[] args) {
        int x = 10;
        int y = 5;
        
        int result = Calculator.add(x, y);
        System.out.println("The result is " + result);
    }
}

class Calculator {
    public static int add(int x, int y) {
        return x + y;
    }
}

 * In this example, we define a Calculator class with a static add method. 
 * We can call the add method directly on the Calculator class 
 * without creating an instance of the class.
*/

//String Class
/*
 * The String class in Java represents a sequence of characters. Recall that
 * it is an Object, not a primitive type and that it is IMMUTABLE. 
 * 
 * public class Main {
    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "World";
        
        String result = str1 + " " + str2;
        System.out.println(result);
    }
}
*/

//Constructors
/*
 * A constructor is a special method that is called when an object is created. 
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25); //will call the Person constructor
        System.out.println(p1);
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    @Override
    public String toString() {
        return "Person{name='" + name + "',

*/

//Using "this" for classes
/* The this keyword in Java refers to the current object instance. Here's an example:
 * public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        System.out.println(p1);
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age; //Notice that with the "this" keyword we can have parameters and variables
        				//of the same name :)
    }
    
    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}
*/

//Instance variables
/*
 * Instance variables are just variables that belong to an Object of the class. 
 * 
 * public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        System.out.println(p1);
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}
 * In this example, name and age are instance variables of Person
*/

//Static variables
/*
 * Static variables are variables that belong to a class rather than an instance of the class. 
 * Here's an example:
 * public class Main {
    public static void main(String[] args) {
        System.out.println("PI = " + Math.PI);
    }
}
*/

//static and non-static methods
/*
 * Static methods are methods that belong to a class rather than an instance of the class, 
 * whereas non-static methods belong to an instance of a class and require an Object of that
 * class to call it. Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        int x = 10;
        int y = 5;
        
        int result1 = Calculator.add(x, y);
        int result2 = Calculator.subtract(x, y);
        //Notice that we didn't have to make Calculator Objects to use these methods
        
        System.out.println("The result of adding " + x + " and " + y + " is " + result1);
        System.out.println("The result of subtracting " + x + " and " + y + " is " + result2);
    }
}

class Calculator {
    public static int add(int x, int y) {
        return x + y;
    }
    
    public static int subtract(int x, int y) {
        return x - y;
    }
}
*/

//get/set methods
/*
 * Getters and setters are methods that allow you to access and modify the values of 
 * instance variables without giving someone complete control of the variable.
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        System.out.println(p1.getName()); // John
        p1.setName("Jane");
        System.out.println(p1.getName()); // Jane
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
		this.name = name;
	}
	
	//Above are two sample getters and setters
*/

//toString()
/*
 * The toString() method is a method that returns a string representation of an object. 
 * It is derived from the Object class. Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        System.out.println(p1.toString());
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    //Notice the override keyword
    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}
*/

//How to write an equals method for a class
/*
 * The equals() method is a method that compares two objects for equality. 
 * This is also derived from the Object class Here's an example:
 * 
public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        Person p2 = new Person("John", 25);
        
        if (p1.equals(p2)) {
            System.out.println("The two persons are equal");
        } else {
            System.out.println("The two persons are not equal");
        }
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        
        if (!(obj instanceof Person)) {
            return false;
        }
        
        Person other = (Person) obj;
        return name.equals(other.name) && age == other.age;
    }
}
*/

//switch statement
/*
 * The switch statement is a control statement that allows you to 
 * choose between several alternatives based on the value of an expression. 
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        int dayOfWeek = 1;
        
        switch (dayOfWeek) {
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            case 4:
                System.out.println("Thursday");
                break;
            case 5:
                System.out.println("Friday");
                break;
            case 6:
                System.out.println("Saturday");
                break;
            case 7:
                System.out.println("Sunday");
                break;
            default:
                System.out.println("Invalid day of week");
                break;
        }
    }
}
* In this example, we use the switch statement to 
* print the name of the day of the week based on the 
* value of the dayOfWeek variable.
*/

//StringBuffer
/*
 * StringBuffer is a class that represents a mutable sequence of characters. 
 * It is good for when we want to append many things to an existing String
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer();
        sb.append("Hello");
        sb.append(" ");
        sb.append("world");
        System.out.println(sb.toString()); // Hello world
    }
}
*/

//One Dimensional Arrays (of primitives and references)
/*
 * Arrays are objects that can hold a fixed number of values of the same type.
 * Here's an example of one with primitives and references (Objects)
 * 
 * public class Main {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5}; // an array of integers
        int[] numbersTwo = new int[5];
        String[] names = {"Alice", "Bob", "Charlie", "Dave"}; // an array of strings
        
        System.out.println("The second number is: " + numbers[1]); // prints "The second number is: 2"
        System.out.println("The third name is: " + names[2]); // prints "The third name is: Charlie"
        
        *Remember this for iterating through arrays*
        for(int i = 0; i < names.length; i++) {
        	System.out.println(names[i]);
        }
    }
}
*/

//Ternary Operator
/*
 * The ternary operator is a shorthand version of an if-else statement. 
 * It takes three operands: a condition, an expression to evaluate if the condition is true, 
 * and an expression to evaluate if the condition is false. 
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        int x = 5;
        int y = 10;
        
        int max = (x > y) ? x : y;
        
        System.out.println("The maximum value is: " + max); // prints "The maximum value is: 10"
    }
}
*/

//Exceptions
/*
 * An exception is an event that occurs during the execution of a program that 
 * disrupts the normal flow of instructions. 
 * Exceptions can be handled using try-catch blocks. 
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        try {
            int x = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("An arithmetic exception occurred: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An exception occurred: " + e.getMessage());
        }
    }
}
* In this example, we intentionally divide a number by zero to generate an ArithmeticException. 
* We handle this exception using a try-catch block and print an error message.
*/

//Privacy Leaks
/*
 * Privacy leaks occur when private data is exposed outside of the class that it belongs to. 
 * This can happen if a public method returns a private instance variable, 
 * or if a public method takes a private instance variable as a parameter. 
 * Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        String name = p1.getName(); // privacy leak
        System.out.println("Name: " + name);
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public String getName() {
        return name; // privacy leak
    }
}
*/

//Copying Objects: Shallow, Reference, Deep Copying
/*
 * There are three types of copying objects in Java:
 * 
 * Shallow copying: When you perform a shallow copy, 
 * you create a new object with the same instance variables as the original object. 
 * However, the new object shares the same references to objects 
 * as the original object. Here's an example:
 * 
 * public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        Person p2 = new Person(p1); // shallow copy
        System.out.println("p1: " + p1);
        System.out.println("p2: " + p2);
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public Person(Person p2) {
        this.name = p2.name;
        this.age = p2.age;
    }
    
    public String toString() {
        return "Name: " + name + ", Age: " + age;
    }
}
In this example, we have a Person class with a private instance variable name and age. 
We create a new Person object p1 and assign it to p2, 
which performs a shallow copy. Both p1 and p2 reference the same Person object.

Reference copying: When you perform a reference copy, 
you create a new reference to the same object. 
Here's an example:

public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        Person p2 = p1; // reference copy
        p2.setName("Mary");
        System.out.println("p1: " + p1);
        System.out.println("p2: " + p2);
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String toString() {
        return "Name: " + name + ", Age: " + age;
    }
}
In this example, we have a Person class with a private instance variable name and age. 
We create a new Person object p1 and assign it to p2, which performs a reference copy. 
We then modify the name of p2 using the setName() method, which changes the name of p1 as well 
because they both reference the same Person object.

Deep copying: When you perform a deep copy, you create a new object with its own copy 
of the instance variables. Here's an example:

public class Main {
    public static void main(String[] args) {
        Person p1 = new Person("John", 25);
        Person p2 = new Person(p1); // deep copy
        p2.setName("Mary");
        System.out.println("p1: " + p1);
        System.out.println("p2: " + p2);
    }
}

class Person {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    //Notice the new keyword for the name, it is an Object.
    public Person(Person other) {
        this.name = new String(other.name);
        this.age = other.age;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String toString() {
        return "Name: " + name + ", Age: "
*/

//Abstraction
/*
 * Abstraction is a way to simplify complex things 
 * by focusing on their most important features and ignoring the rest of the details. 
 * It's like looking at a car and knowing that it has wheels, an engine, and seats, 
 * without worrying about how the engine works or how the seats are made. 
 * In programming, abstraction means creating simple and modular building blocks (like classes) 
 * that can be used to build more complex systems. 
 * By hiding the implementation details behind a well-defined interface, 
 * abstraction makes it easier to work with these building blocks and create larger programs.
 * 
 * public interface Animal {
    void makeSound();
}

public class Dog implements Animal {
    public void makeSound() {
        System.out.println("Woof!");
    }
}

public class Cat implements Animal {
    public void makeSound() {
        System.out.println("Meow!");
    }
}

public class Main {
    public static void main(String[] args) {
        Animal dog = new Dog();
        dog.makeSound();
        
        Animal cat = new Cat();
        cat.makeSound();
    }
}
* In this case (the main method, we can make a new dog and cat and use .makeSound() without worrying about
* how it is implemented, which is abstraction!
*/

//Encapsulation
/*
 * Encapsulation is a way of organizing code so that the internal details of an object are 
 * hidden from the outside world. It involves bundling related data and behaviors into a 
 * single unit, and controlling access to that unit through a public interface.
 * Think of a vending machine as an example of encapsulation. 
 * You put in money and press a button to get a product, but you don't need to know how the machine is built or how it works internally. 
 * The machine is designed to provide a public interface (the buttons and the display), 
 * while hiding the internal details (the mechanisms that dispense the product and the change). 
 * This makes it easy to use and prevents accidental damage or misuse.
 * 
 * In simple terms, encapsulation is about hiding the implementation details of an object and 
 * exposing only a public interface for interacting with it, while abstraction is about 
 * representing the essential characteristics of an object without including the unnecessary details.
*/

//Interfaces
/*
 * Interfaces are essentially blueprints for classes. They define what a class of that interface should
 * have. For example, a shape should have a getArea() method and a getPerimeter() method
 * public interface Shape {
    public double getArea();
    public double getPerimeter();
}
public class Circle implements Shape {
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }

    public double getPerimeter() {
        return 2 * Math.PI * radius;
    }
}
 *
 *In this example, we have a Circle class that implements the Shape interface. 
 *It has a private instance variable radius and a constructor that takes a radius parameter. 
 *It provides an implementation for the getArea() and getPerimeter() methods, 
 *which calculate the area and perimeter of the circle, respectively, based on the radius.
 *By implementing the Shape interface, the Circle class agrees to provide implementations 
 *for the getArea() and getPerimeter() methods, and can be used anywhere that a Shape object is expected. 
 *This demonstrates polymorphism, as different types of shapes can be represented by different classes 
 *that all implement the Shape interface.
*/

//Comparable interface
/*
 * The Comparable interface in Java allows objects of a class to be compared with each other.
 * Here's an example: let's say we have a class called Person with attributes name and age. 
 * We want to be able to compare Person objects based on their age. To do this, 
 * we can implement the Comparable interface in our Person class, 
 * which requires us to implement a single method: compareTo.
 * 
 * public class Person implements Comparable<Person> {
    private String name;
    private int age;
    
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    public int compareTo(Person otherPerson) {
        return this.age - otherPerson.age;
    }
}
 In the compareTo method, we return an integer value that represents the order of the objects being compared. 
 If this object is "less than" the otherPerson object, we return a negative number.
 If this object is "greater than" the otherPerson object, we return a positive number. 
 If this object is "equal to" the otherPerson object, we return 0.
 Now we can use the compareTo method to compare Person objects and sort them in ascending or 
 descending order based on their age.
 
List<Person> people = new ArrayList<>();
people.add(new Person("Alice", 30));
people.add(new Person("Bob", 25));
people.add(new Person("Charlie", 35));

Collections.sort(people); // sorts by age in ascending order

for (Person person : people) { //This is called an enhanced for-loop, you will not need to know this :)
    System.out.println(person.getName() + " " + person.getAge());
}
*/

//Polymorphism with Interface types
/*
 * Polymorphism with interface types refers to the ability of objects of different classes to be treated 
 * as if they belong to a common class or interface. This means that if two classes implement the 
 * same interface, objects of these classes can be used interchangeably wherever the interface is expected,
 * without the need to know the specific class.
 * 
 * public class Main {
    public static void main(String[] args) {
        Shape[] shapes = new Shape[2];
        Shape shapeOne = new Rectangle(3,10); //Shape and Rectangle!!??!!?
        shapeOne = new Circle(5);
        
        shapes[0] = new Rectangle(5, 10); //Notice that this is a Shape[] but we can put Rectangle and Circle!
        shapes[1] = new Circle(5);
		
        for (Shape shape : shapes) {
            System.out.println("Area: " + shape.getArea());
        }
    }
} 
*/

//Wrappers
/*
 * In Java, a wrapper class is a class that provides an object-oriented representation of a primitive data type. 
 * This allows the primitive data types to be used in contexts that require objects. 
 * The Java language provides eight primitive data types: boolean, byte, short, int, long, float, double, and char. 
 * For each of these primitive types, Java provides a corresponding wrapper class, 
 * which is used to wrap the primitive value in an object.
 * 
 * The wrapper classes are:

	Boolean
	Byte
	Short
	Integer
	Long
	Float
	Double
	Character
 * Wrapper classes are useful in situations where a method requires an object, 
 * not a primitive value. For example, many of the classes in the Java Collections Framework require objects, 
 * so if you want to use a primitive value with one of these classes, you need to wrap it in a corresponding wrapper class.
 * 
 * Consider how we use Integer in something like: ArrayList<Integer> arrayList = new ArrayList<Integer>(); :)
*/

//Method Overloading
/*
 * Methods with the same name, but with different signatures (parameter list)
 * public class MathUtils {
    public static int add(int a, int b) {
        return a + b;
    }

    public static double add(double a, double b) {
        return a + b;
    }

    public static int add(int a, int b, int c) {
        return a + b + c;
    }
}
In this example, we have a MathUtils class with three static methods named add().
Each method takes a different number or type of arguments, and returns the sum of those arguments.
Method overloading is a feature in Java that allows multiple methods in the same class 
to have the same name, as long as they have different method signatures 
(i.e. different number or types of parameters). When a method is called with a particular set of arguments,
Java will choose the appropriate method to execute based on the method signature that matches the arguments.
*/

//break and continue
/*
 * In Java, continue and break are control flow statements used to alter the normal flow of execution in a loop or switch statement.

	break is used to terminate the current loop or switch statement and continue executing the next statement after the loop or switch. 
	For example:
	
	for (int i = 0; i < 10; i++) {
    if (i == 5) {
        break;
    }
    System.out.println(i);
	}

	In this example, the loop will iterate from 0 to 9, but when i is equal to 5, the break statement is executed 
	and the loop is terminated. The output of the program will be: 
	0
	1
	2
	3
	4
	
	continue is used to skip the current iteration of a loop and continue with the next iteration. 
	For example:
	for (int i = 0; i < 10; i++) {
    if (i == 5) {
        continue;
    }
    System.out.println(i);
}
	In this example, when i is equal to 5, the continue statement is executed 
	and the current iteration of the loop is skipped. 
	The output of the program will be:
	0
	1
	2
	3
	4
	6
	7
	8
	9
	So, break is used to terminate a loop or switch statement prematurely, 
	while continue is used to skip the current iteration of a loop 
	and continue with the next iteration.
*/

/* ArrayList
 * ArrayList is a class in Java's util package that provides a resizable array implementation. 
 * It allows you to add, remove, and access elements in the list using methods like add(), remove(), and get().
 * Here's an example of some of it's methods:
import java.util.ArrayList;

public class Example {
    public static void main(String[] args) {
        ArrayList<String> fruits = new ArrayList<>();

        fruits.add("apple");
        fruits.add("banana");
        fruits.add("cherry");

        System.out.println(fruits); // prints [apple, banana, cherry]

        fruits.remove("banana");
		
        System.out.println(fruits); // prints [apple, cherry]
        System.out.println(fruits.size()) // prints 2
    }
}
*/

//Stacks
/*
 * Stack is a class in Java's util package that provides a last-in, first-out (LIFO) stack implementation. 
 * It allows you to add elements to the top of the stack using the push() method, and remove elements from the top of the stack using the pop() method.
 * Here's an example of some of it's methods:
import java.util.Stack;

public class Example {
    public static void main(String[] args) {
        Stack<String> stack = new Stack<>();

        stack.push("apple");
        stack.push("banana");
        stack.push("cherry");

        System.out.println(stack); // prints [apple, banana, cherry]

        String topElement = stack.pop();

        System.out.println(topElement); // prints cherry
        System.out.println(stack); // prints [apple, banana]
    }
}

*/
//Two Dimensional Arrays (of primitives and references)
/*
* A two-dimensional array is an array of arrays, where each element in the outer array is itself an array. 
* To create a two-dimensional array in Java, you specify the number of rows and columns in the array when you declare it. 
* In this example, we create a 3x3 two-dimensional array of int values by declaring int[][] grid = new int[3][3];
* 
* public class Example {
    public static void main(String[] args) {
        int[][] grid = new int[3][3];
		
		//Filling in the values of the 2D array, be sure to know the difference between rows and columns
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                grid[i][j] = i * j;
            }
        }
		
		//Printing out the array, understand how this works
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(grid[i][j] + " ");
            }
            System.out.println();
        }
    }
}
*/
/*
 * For-each (enhanced) loops:
 For-each loops in Java provide a concise way to iterate over elements in an array or collection. 
 They eliminate the need for manually managing loop indices and simplify the code.
 Note that in order to use, the Object must have a defined iterator
 Here's an example of using a for-each loop to iterate over an array of integers:
 public class Example {
    public static void main(String[] args) {
 	int[] numbers = {1, 2, 3, 4, 5};

	for (int number : numbers) {
    System.out.println(number);
	}
}
*/
/*
 * String Class Methods:
	The String class in Java provides various methods to manipulate and analyze strings. Here are some commonly used methods:
	toLowerCase(): Converts the string to lowercase.
	toUpperCase(): Converts the string to uppercase.
	length(): Returns the length of the string.
	charAt(index): Returns the character at the specified index.
	substring(startIndex, endIndex): Returns a substring of the original string.
	isEmpty(): Checks if the string is empty.
	
	String name = "John Doe";
	System.out.println(name.toLowerCase());
	System.out.println(name.toUpperCase());
	System.out.println(name.length());
	System.out.println(name.charAt(2));
	System.out.println(name.substring(0, 4));
	System.out.println(name.isEmpty());
*/
/* ArrayList Class Methods:
	ArrayList is a dynamic array-like class in Java that provides several useful methods. Here are some commonly used methods:
	add(element): Adds an element to the ArrayList.
	get(index): Retrieves the element at the specified index.
	isEmpty(): Checks if the ArrayList is empty.
	indexOf(element): Returns the index of the first occurrence of the element.
	remove(index): Removes the element at the specified index.
	size(): Returns the number of elements in the ArrayList.
	
	ArrayList<String> fruits = new ArrayList<>();
	fruits.add("Apple");
	fruits.add("Banana");
	fruits.add("Orange");
	
	System.out.println(fruits.get(1));
	System.out.println(fruits.isEmpty());
	System.out.println(fruits.indexOf("Banana"));
	fruits.remove(0);
	System.out.println(fruits.size());
*/
/*
 * Comparable Interface (compareTo method):
The Comparable interface in Java allows objects to be compared for ordering. 
It contains the compareTo() method, which compares the current object with another object 
and returns an integer indicating the relative order.
	Example usage:

	public class Person implements Comparable<Person> {
	    private String name;
	    private int age;
	
	    // Constructor and other methods
	
	    @Override
	    public int compareTo(Person otherPerson) {
	        return this.age - otherPerson.age;
	    }
	}
*/

/* Sorting Data Using Collections.sort():
The Collections.sort() method in Java is used to sort elements in a collection in ascending order. 
It requires the elements to implement the Comparable interface or provide a custom Comparator for sorting.
Example usage:

List<Integer> numbers = new ArrayList<>();
numbers.add(5);
numbers.add(2);
numbers.add(8);

Collections.sort(numbers);

System.out.println(numbers);  // Output: [2, 5, 8] 
*/

/* Polymorphism:
Polymorphism in Java allows objects of different classes to be treated as objects of a common superclass or interface. 
It enables flexibility and extensibility in object-oriented programming.

public interface Animal {
    void makeSound();
}

public class Dog implements Animal {
    @Override
    public void makeSound() {
        System.out.println("Woof!");
    }
}

public class Cat implements Animal {
    @Override
    public void makeSound() {
        System.out.println("Meow!");
    }
}

Animal dog = new Dog();
Animal cat = new Cat();

dog.makeSound(); // Output: Woof!
cat.makeSound(); // Output: Meow!
*/

/* Method Overloading/Overriding:
Method overloading is when a class has multiple methods with the same name but different parameters. 
The method to be called is determined at compile-time based on the number and types of arguments passed. 
Method overriding is when a subclass provides a different implementation for a method that is already defined in its superclass. 
The method to be called is determined at runtime based on the actual object type.

class Shape {
    public void draw() {
        System.out.println("Drawing a shape");
    }
    
    public void draw(String color) {
        System.out.println("Drawing a shape with color: " + color);
    }
}

class Circle extends Shape {
    @Override
    public void draw() {
        System.out.println("Drawing a circle");
    }
}

Shape shape = new Shape();
shape.draw();               // Output: Drawing a shape
shape.draw("Red");          // Output: Drawing a shape with color: Red

Circle circle = new Circle();
circle.draw();              // Output: Drawing a circle
circle.draw("Blue");        // Output: Drawing a shape with color: Blue
In the example, the Shape class has two draw() methods, one with no parameters and another with a String parameter. 
The Circle class overrides the draw() method from its superclass to provide a different implementation. 
When invoking the draw() method on shape or circle, the method to be called is determined based on the object's actual type.
*/

/* Iterators:
An iterator is a Java object that enables iteration over a collection, such as an ArrayList. 
It provides methods for checking if there are more elements in the collection and for retrieving the next element.
Allows you to use the for-each loop.
ArrayList<String> fruits = new ArrayList<>();
fruits.add("Apple");
fruits.add("Banana");
fruits.add("Orange");

Iterator<String> iterator = fruits.iterator();

while (iterator.hasNext()) {
    String fruit = iterator.next();
    System.out.println(fruit);
} 
*/

/* getClass(), instanceof:
getClass() is a method defined in the Object class that returns the runtime class of an object. 
instanceof is an operator that returns true if an object is an instance of a specified class or its subclass.

String name = "John";
System.out.println(name.getClass());        // Output: class java.lang.String
System.out.println(name instanceof String); // Output: true

Object obj = new ArrayList<>();
System.out.println(obj.getClass());          // Output: class java.util.ArrayList
System.out.println(obj instanceof ArrayList); // Output: true
In the example, getClass() is used to obtain the runtime class of a String object and an ArrayList object. 
instanceof is used to check if an object is an instance of String or ArrayList.
*/ 

/* Recursion:
Recursion is a programming technique where a function calls itself to solve a problem. 
The function must have a base case that terminates the recursion and a recursive case that calls itself with a smaller input.

class Factorial {
    public static int factorial(int n) {
        if (n == 0 || n == 1) {
            return 1;
        } else {
            return n * factorial(n - 1);
        }
    }
}

int result = Factorial.factorial(5);
System.out.println(result);  //120

In the example, the factorial() method calculates the factorial of a number using recursion. 
The base case checks if the number is 0 or 1 and returns 1. 
Otherwise, it calls itself with n-1 as the argument and multiplies the result by n.
*/ 

/* Integer.parseInt(), Double.parseDouble():
Integer.parseInt() is a method that converts a string representation of an integer into an actual int value.
Double.parseDouble() does the same for double values.

String numberStr = "123";
int number = Integer.parseInt(numberStr);
System.out.println(number);  // Output: 123

String doubleStr = "3.14";
double pi = Double.parseDouble(doubleStr);
System.out.println(pi);      // Output: 3.14
In the example, the parseInt() and parseDouble() methods are used to convert string representations of numbers 
into their respective primitive types (int and double).
*/

/* Inheritance (extending other classes using "extends"):
Inheritance is a fundamental concept in object-oriented programming where a class can inherit properties and behaviors from another class. 
The subclass (derived class) extends the superclass (base class) using the extends keyword.

class Vehicle {
    protected String brand;

    public Vehicle() {
        this.brand = "Unknown";
    }

    public void drive() {
        System.out.println("Driving the vehicle");
    }
}

class Car extends Vehicle {
    private int numOfDoors;

    public Car(int numOfDoors) {
        this.numOfDoors = numOfDoors;
    }

    public void honk() {
        System.out.println("Honking the car horn");
    }
}

Car car = new Car("Toyota", 4);
System.out.println(car.brand);       // Output: Toyota
System.out.println(car.numOfDoors);  // Output: 4
car.drive();                         // Output: Driving the vehicle
car.honk();                          // Output: Honking the car horn
In the example, the Vehicle class is the superclass, and the Car class is the subclass that extends the Vehicle class. 
The Car class inherits the brand property and the drive() method from the Vehicle class, 
and it adds its own numOfDoors property and honk() method. An instance of Car is created, and its properties and methods are accessed.
*/

/* Early and late binding:
Early binding, also known as static binding, is the process of linking a method call to its implementation at compile-time based on the type of the reference variable. 
Late binding, also known as dynamic binding, occurs at runtime, where the method implementation is determined based on the actual object's type. 
Polymorphism is closely related to late binding.

class Animal {
    public void makeSound() {
        System.out.println("Animal makes a sound");
    }
}

class Dog extends Animal {
    @Override
    public void makeSound() {
        System.out.println("Dog barks");
    }
}

Animal animal1 = new Animal();
Animal animal2 = new Dog();

animal1.makeSound();  // Output: Animal makes a sound
animal2.makeSound();  // Output: Dog barks
In the example, the makeSound() method is invoked on two different objects: animal1 of type Animal and animal2 of type Dog. 
During early binding, the compiler determines the method to be called based on the declared type of the reference variable. 
Therefore, animal1.makeSound() calls the makeSound() method defined in the Animal class. However, during late binding, 
the actual object type is considered, and the appropriate implementation of the method is executed. 
Hence, animal2.makeSound() calls the makeSound() method overridden in the Dog class, resulting in "Dog barks" being printed.
*/