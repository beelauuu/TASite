import java.util.ArrayList;
import java.util.Stack;

public class Main {
	
	public static void main(String[] args) { 
	}
}
