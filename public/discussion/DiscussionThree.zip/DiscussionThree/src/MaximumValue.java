import java.util.Scanner;

public class MaximumValue {
	public static void main(String[] args) {
		int num;
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter a value between 0 and 100");
		num = input.nextInt();
		
		if(num > 100) {
			System.out.println("Value too high");
		}
		else if(num < 0) {
			System.out.println("Value too low");
		}
		else {
			System.out.println("Thank you");
		}
		
		
	}
}
