import java.util.Scanner;

public class OfficeHours {
	public static void main(String[] args) {		
		String day;
		Scanner input = new Scanner(System.in);

		day = input.next();
		
		if(day.equals("Saturday")) {
			System.out.println("No weekend office hours");
		}
		else if(day.equals("Sunday")) {
			System.out.println("No weekend office hours");
		}
		else if(day.equals("Monday")) {
			System.out.println("Rose & Mike");
		}
		else if(day.equals("Tuesday")) {
			System.out.println("Peter & Mike");
		}
		else if(day.equals("Wednesday")) {
			System.out.println("Peter");
		}
		else if(day.equals("Thursday")) {
			System.out.println("Laura");
		}
		else if(day.equals("Friday")) {
			System.out.println("Laura");
		}
		else {
			System.out.println("Invalid value, enter in a day of the week");
		}		
	}
}
