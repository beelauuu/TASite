
public class CodingBat {
	public int[] fix23(int[] nums) {
		  for(int i = 0; i < nums.length - 1; i++) {
		    if(nums[i] == 2 && nums[i+1] == 3) {
		        nums[i+1] = 0;
		    }
		  }
		  
		  return nums;
		}

		// [1,2,3]
		// i=0 -> nums[i] = 1
		// i+1=1 -> nums[i] = 2

		// [1,2,3]
		// i=1 -> nums[i] = 2
		// i+1=2 -> nums[i] = 3 (changes to 0)

		// [1,2,3]
		// i=2 -> nums[i] = 3
		// i+1=3 -> out of bounds
	
	public int[] makeEnds(int[] nums) {
		  int[] toReturn = new int[2];
		  toReturn[0] = nums[0];
		  toReturn[1] = nums[nums.length-1];
		  return toReturn;
		}
	
	public boolean has23(int[] nums) {
	    for(int i = 0; i < nums.length; i++) {
	        if(nums[i] == 2 || nums[i] == 3) {
	          return true;
	        }
	    }
	    
	    return false;
	}
	
	public int start1(int[] a, int[] b) {
	    int hasOneAsStart = 0;
	    
	    if(a.length > 0 && a[0] == 1) {
	        hasOneAsStart++;
	    }
	    if(b.length > 0 && b[0] == 1) {
	        hasOneAsStart++;
	    }
	    
	    return hasOneAsStart;
	}
	
	public int[] midThree(int[] nums) {
	    int[] toReturn = new int[3];
	    int middle = nums.length / 2;
	    toReturn[0] = nums[middle-1];
	    toReturn[1] = nums[middle];
	    toReturn[2] = nums[middle+1];
	    return toReturn;    
	}
	
	public int[] makePi() {
	    int[] toReturn = new int[3];
	    toReturn[0] = 3;
	    toReturn[1] = 1;
	    toReturn[2] = 4;
	    
	    int[] toReturnTwo = {3,1,4};
	    
	    return new int[]{3,1,4};
	}
	
	public int[] frontPiece(int[] nums) {
	    if(nums.length == 0) {
	      return new int[0];
	    }
	    if(nums.length == 1) {
	        int[] toReturn = new int[1];
	        toReturn[0] = nums[0];
	        return toReturn;
	    }
	    
	    int[] toReturn = new int[2];
	    toReturn[0] = nums[0];
	    toReturn[1] = nums[1];
	    return toReturn;
	    
	}

	public int[] fizzArray(int n) {
	    int[] toReturn = new int[n];
	    
	    for(int i = 0; i < toReturn.length; i++) {
	        toReturn[i] = i;
	    }
	    
	    return toReturn;
	    
	}
	
	public int[] shiftLeft(int[] nums) {
		  
		  if(nums.length == 0) {
		    return nums;
		  }
		  
		  int firstElement = nums[0];
		  
		  for(int i = 0; i < nums.length - 1; i++) {
		      nums[i] = nums[i+1];
		  }
		  
		  nums[nums.length - 1] = firstElement;
		  return nums;
		  
		  // [6, 2, 5 ,3]
		  // [2, 5, 3, 6]
		  
	}
	
	public boolean more14(int[] nums) {
	    int numOnes = 0;
	    int numFours = 0;
	    
	    for(int i = 0; i < nums.length; i++) {
	        if(nums[i] == 1) {
	          numOnes++;
	        }
	        if(nums[i] == 4) {
	          numFours++;
	        }
	    }
	    
	    if(numOnes > numFours) {
	      return true;
	    }
	    return false;
	}
	
	public int[] pre4(int[] nums) {
	    int lengthOfNewArray = 0;
	    
	    for(int i = 0; i < nums.length; i++) {
	      if(nums[i] == 4) {
	        break;
	      }
	      lengthOfNewArray++;
	    }
	    
	    int[] toReturn = new int[lengthOfNewArray];
	    
	    for(int i = 0; i < toReturn.length; i++) {
	      toReturn[i] = nums[i];
	    }
	    
	    return toReturn;	 
	}
	
	public boolean has12(int[] nums) {
	    boolean hasSeenAOne = false;
	    
	    for(int i = 0; i < nums.length; i++) { 
	        if(nums[i] == 1) {
	          hasSeenAOne = true;
	        } 
	        else if(nums[i] == 2 && hasSeenAOne == true) {
	          return true;
	        }
	    }
	    
	    return false;
	}
	
	public boolean twoTwo(int[] nums) {
	    for(int i = 0; i < nums.length; i++) {
	      if(nums[i] == 2) {
	          boolean leftCondition = (i > 0 && nums[i-1] == 2);
	          boolean rightCondition = (i < nums.length - 1 && nums[i+1] == 2);
	          
	          if(!leftCondition && !rightCondition) {
	              return false;
	          }
	      }
	    }
	    
	    return true;
	}

	
	
	public static void main(String[] args) {
		String test = "cat";
		
		System.out.println(test.length() );
		
		char[] testTwo = {'c','a','t'};
		int[] arrayTwo = new int[3];
		arrayTwo[0] = 1;
		arrayTwo[1] = 2;
		arrayTwo[2] = 3;
		
		int[] arrayThree = {1,2,3};
		
		System.out.println(testTwo.length );
	}







}
