
public class Utilities {
	public static boolean isPalindrome(String word) {		
		int start = 0;
		int end = word.length() - 1;
		
		// r a c e f a r
		
		while(start < end) {
			if(word.charAt(start) != word.charAt(end)) {
				return false;
			}
			start++;
			end--;
		}
		
		return true;
	}
	
	public static String encode(String str) {
		StringBuilder encodedStr = new StringBuilder("");
		
		for(int i = 0; i < str.length(); i++) {
			char curr = str.charAt(i);
			encodedStr.append((char)(curr - 44));
		}
		
		return encodedStr.toString();
	}
	
	public static String decode(String str) {
		StringBuilder decodedStr = new StringBuilder("");
		
		for(int i = 0; i < str.length(); i++) {
			char curr = str.charAt(i);
			decodedStr.append((char)(curr + 44));
		}
		
		return decodedStr.toString();
		
	}
	
	public static String centralize(String word, int width) {
		if(width < word.length()) {
			return null;
		}
		
		int padding = (width - word.length()) / 2;
		
		String toReturn = "";
		
		//   
		for(int i = 0; i < padding; i++) {
			toReturn += " ";
		}
		//   cat
		toReturn += word;
		
		//   cat   
		for(int i = 0; i < padding; i++) {
			toReturn += " ";
		}
		
		return toReturn;
		
		
	}
}
