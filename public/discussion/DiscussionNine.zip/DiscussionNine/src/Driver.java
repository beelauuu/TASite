
public class Driver {
	public static void main(String[] args) {
		System.out.println(Utilities.centralize("cat", 9));
	}
}
