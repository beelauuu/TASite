import java.util.Scanner;
/*
 * Write a program that 
 * reads three doubles values 
 * and determines the maximum value.
 */
public class MaxValue {
	public static void main(String[] args) {
		double numOne;
		double numTwo;
		double numThree;
		
		Scanner s = new Scanner(System.in);
		numOne = s.nextDouble();
		numTwo = s.nextDouble();
		numThree = s.nextDouble();
		
		//Check if number one is > number two and if number one is > number three
		//Check if number two is > number one and if number two is > number three
		if(numOne > numTwo && numOne > numThree) {
			System.out.println(numOne + " is the max");
		}
		else if(numTwo > numOne && numTwo > numThree) {
			System.out.println(numTwo + " is the max");
		}
		else {
			System.out.println(numThree + " is the max");
		}
	}
}
