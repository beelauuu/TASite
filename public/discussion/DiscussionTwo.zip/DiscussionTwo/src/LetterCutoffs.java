import java.util.Scanner;
public class LetterCutoffs {
/*
 * Write a program that reads in two double values, computes the average 
 * and displays a letter grade according to the following cutoffs:
 */
	public static void main(String[] args) {
		double numOne;
		double numTwo;
		
		"Bob".equals("Susie");
		
		Scanner input = new Scanner(System.in);
		numOne = input.nextDouble();
		numTwo = input.nextDouble();
		
		double average = (numOne + numTwo) / 2;
		
		if(average >= 90 && average <= 100) {
			System.out.println("A");
		}
		else if(average >= 80 && average <= 89) {
			System.out.println("B");
		}
		else if(average >= 70 && average <= 79) {
			System.out.println("C");
		}
		else {
			//Assume grade is < 70
			System.out.println("F");
		}

	}

}
