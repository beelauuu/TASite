import java.util.Scanner;

public class IncreasingSequence {
	public static void main(String[] args) {
		int numOne;
		int numTwo;
		int numThree;
		
		Scanner input = new Scanner(System.in);
		numOne = input.nextInt();
		numTwo = input.nextInt();
		numThree = input.nextInt();
		
		// Check if numOne <= numTwo
		// Check if numTwo <= numThree
		
		if(numOne <= numTwo) {
			
			if(numTwo <= numThree) {
				System.out.println("Increasing");
			}
			else {
				System.out.println("Not Increasing");
			}
	
		}
		else {
				System.out.println("Not increasing");
		}
		
		// && (and)
		// || (or)
		
		if(numOne <= numTwo && numTwo <= numThree) {
			System.out.println("Increasing");
		}
		else {
			System.out.println("Not Increasing");
		}
	}
}
