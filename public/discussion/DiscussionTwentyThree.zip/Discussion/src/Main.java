import java.util.ArrayList;
import java.util.Stack;

public class Main {
//	Try out code examples!
}
