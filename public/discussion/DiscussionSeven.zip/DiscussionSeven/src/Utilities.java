import java.util.Random;

public class Utilities {
	
	
	public static int maximum(int numOne, int numTwo, int numThree) {
		if(numOne > numTwo && numOne > numThree) {
			return numOne;
		}
		else if(numTwo > numOne && numTwo > numThree) {
			return numTwo;
		}
		else {
			return numThree;
		}
	}
	
	public static int getNumberVowels(String word) {
		if(word == null) {
			return -1;
		}
		
		int numOfVowels = 0;
		
		word = word.toLowerCase();
		
		for(int i = 0; i < word.length(); i++) {
			char currChar = word.charAt(i);
			
			if(currChar == 'a' || currChar == 'e' || currChar == 'i' || currChar == 'o' || currChar == 'u') {
				numOfVowels++;
			}
		}
		
		return numOfVowels;
	}
	
	public static String drawSquare(int rows, char charOne, char charTwo) {
		
		 if(Utilities.areParametersValid(rows, charOne, charTwo) == false) {
			 return null;
		 }
		
		 String toReturn = "";
		 Random r = new Random();
		 
		 
		 //Corresponds to the amount of rows
		 for(int i = 0; i < rows; i++) {
			 
			 for(int j = 0; j < rows; j++) {
				 boolean whichChar = r.nextBoolean();
				 
				 if(whichChar == true) {
					 toReturn += charOne;
				 }
				 else {
					 toReturn += charTwo;
				 }
				 
			 }
			 
			 toReturn += "\n";
		 }
		 
		 return toReturn;		 
	}
	
	public static String drawSquareBorders(int rows, char symbol) {
		String toReturn = "";
		
		for(int i = 0; i < rows; i++) {
			if(i == 0 || i == rows-1) {
				for(int j = 0; j < rows; j++) {
					toReturn += symbol;
				}
			}
			else {
				toReturn += symbol;
				
				for(int j = 0; j < rows - 2; j++) {
					toReturn += " ";
				}
				
				toReturn += symbol;
			}
			
			toReturn += "\n";
		}
		
		return toReturn;
		
	}
	
	private static boolean areParametersValid(int numRows, char charOne, char charTwo) {
		if(numRows >= 2 && charOne != charTwo) {
			return true;
		}
		
		return false;
	}
	
	
	
	
}
