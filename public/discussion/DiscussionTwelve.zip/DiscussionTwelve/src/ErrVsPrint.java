public class ErrVsPrint {
    public static void main(String[] args) {
        System.out.println("This is a regular message using System.out.println");
        
        // Simulating an error
        try {
            int result = divideByZero();
            System.out.println("Result: " + result); // This line won't be executed
        } catch (Exception e) {
            // Printing the error message to the standard error stream
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static int divideByZero() {
        return 10 / 0; // This will throw an ArithmeticException
    }
}
