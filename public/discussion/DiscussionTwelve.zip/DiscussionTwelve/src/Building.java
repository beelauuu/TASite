
public class Building {
		private String nameOfBuilding;
		private int numberOfFloors;
		private static int numberOfBuildingWeHave = 0;
		private StringBuffer residents;
		
		
		  public Building(String buildingName, int numberOfFloors) {
		  this.numberOfFloors = numberOfFloors; 
		  nameOfBuilding = buildingName;
		  numberOfBuildingWeHave++; 
		  residents = new StringBuffer();
		  }
		  
		  public Building(String buildingName) {
		  this.numberOfFloors = 1; 
		  nameOfBuilding = buildingName;
		  numberOfBuildingWeHave++; 
		  residents = new StringBuffer();
		  }
		  
		  public Building(int numberOfFloors) {
		  this.numberOfFloors = numberOfFloors; 
		  nameOfBuilding = "DEFAULT";
		  numberOfBuildingWeHave++; 
		  residents = new StringBuffer();
		  }
		  
		  public Building() {
			  this.numberOfFloors = 1;
			  this.nameOfBuilding = "DEFAULT";
			  numberOfBuildingWeHave++;
			  residents = new StringBuffer();
		  }
		  
		  public Building(Building building) {
			  this(building.nameOfBuilding, building.numberOfFloors);
			  this.residents = new StringBuffer(building.residents);
		  }
		 
		
////		Pretty much equivalent to constructor
//		public void init(String buildingName, int numberOfFloors) {
//			this.numberOfFloors = numberOfFloors;
//			nameOfBuilding = buildingName;
//			numberOfBuildingWeHave++;
//		}
	
		  
//		Getters
		public String getName() {
			return nameOfBuilding;
		}
		
		public int getNumberOfFloors() {
			return numberOfFloors;
		}
		
		public StringBuffer getResidents() {
			return residents;
		}
		
		public static int getNumberOfBuildings() {
			return numberOfBuildingWeHave;
		}
		
//		Setters
		public void setName(String newName) {
			nameOfBuilding = newName;
		}
		
		public void setNumberOfFloors(int numberOfFloors) {
			this.numberOfFloors = numberOfFloors;
		}
		
		public void setNumberOfResidents(StringBuffer residents) {
			this.residents = residents;
		}
		
		public void addResident(String resident) {
			residents.append(resident);
		}
		
		
		public void printBuildingInfo() {
			System.out.println("The name of this building is: " + nameOfBuilding);
			System.out.println("The number of floors is: " + numberOfFloors);
		}
		
		public String toString() {
			return "Name: " + nameOfBuilding + " " + "Number Of Floors: " + numberOfFloors
					+ " Residents: " + residents;
		}
		
		public boolean equals(Object obj) {
			if(obj == this) {
				return true;
			}
			if(obj == null || getClass() != obj.getClass()) {
				return false;
			}
			
			Building building = (Building) obj;
			
			return nameOfBuilding.equals(building.nameOfBuilding) && numberOfFloors == building.numberOfFloors 
					&& residents.compareTo(building.residents) == 0;

		}
		
		
}
