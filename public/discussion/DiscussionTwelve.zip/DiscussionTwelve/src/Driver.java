
public class Driver {
	public static void main(String[] args) {
		Building b = new Building("IRB", 3);
		Building b2 = new Building("IRB", 4);
		
		System.out.println(b.equals(b2));
	
		
	}
}
