import java.util.Scanner;
public class Rewrite {

	public static void main(String[] args) {
		  int age;
		  Scanner scanner = new Scanner(System.in);

		  do {
			  
		      System.out.print("Enter age: ");
		      age = scanner.nextInt();
		      if (age < 0) {
		          System.out.println("Wrong value.");
		      }
		      
		  } while (age < 0);

		  System.out.println("Correct value provided. " + age);
		  scanner.close();

	}

}
