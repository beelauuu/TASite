import java.util.Scanner;
public class Odds {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int a;
		int b;
		
		a = input.nextInt();
		b = input.nextInt();
		
		if(a > b) {
			System.out.println("Invalid Range");
		}
		else {
			int total = 0;
			while(a <= b) {
				if(a % 2 == 1) {
					total += a;
				}
				a++;
			}
			System.out.println(total);
		}
		
		input.close();
	}
}
