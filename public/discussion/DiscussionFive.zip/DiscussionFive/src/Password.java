import java.util.Scanner;
public class Password {

	public static void main(String[] args) {
		String password;
		Scanner input = new Scanner(System.in);
		
		do {
			password = input.next();
			
			if(password.equals("Terps")) {
				System.out.println("Login Successful");
			}
			else {
				System.out.println("Invalid password");
			}
		}
		while(!password.equals("Terps"));
	}

}
