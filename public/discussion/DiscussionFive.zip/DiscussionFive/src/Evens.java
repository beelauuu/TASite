import java.util.Scanner;


public class Evens {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int numOne;
		int numTwo;
		
		numOne = input.nextInt();
		numTwo = input.nextInt();
		
		while(numOne <= numTwo) {
			if(numOne % 2 == 0) {
				System.out.println(numOne);
			}
			numOne += 1;
		}
		
	}
}
