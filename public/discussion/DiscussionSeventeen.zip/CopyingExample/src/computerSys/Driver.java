package computerSys;

public class Driver {

	public static void main(String[] args) {
		Mouse mouse;

		mouse = new Mouse("IBM");
		mouse.changeCoordinates(10, 20);
		System.out.println(mouse);
		
		Computer computer;
		computer = new Computer("Dell", "OpticalMouse");
		computer.moveMouse(10, 20);
		System.out.println(computer);
	}

}
