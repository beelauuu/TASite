package computerSys;

public class Mouse {
	private String brand;
	private int x, y;

	/* Allow us to create a Mouse object */
	public Mouse() {
	}

	public Mouse(String brand) {
		if (brand == null) {
			throw new IllegalArgumentException("You dropped the ball :)");
		}
		this.brand = brand;
		x = y = 0;
	}

	public String toString() {
		return brand + ", " + x + ", " + y;
	}

	public void changeCoordinates(int x, int y) {
		this.x = x;
		this.y = y;
	}
	public void changeName(String name) {
		this.brand = name;
	}

	public static Mouse referenceCopy(Mouse mouse) {
		return mouse;
	}

	public static Mouse deepCopy(Mouse mouse) {
		Mouse newMouse = new Mouse();
		newMouse.x = mouse.x;
		newMouse.y = mouse.y;
		newMouse.brand = new String(mouse.brand);
		
		return newMouse;
	}

	public static Mouse shallowCopy(Mouse mouse) {
		Mouse newMouse = new Mouse();
		newMouse.x = mouse.x;
		newMouse.y = mouse.y;
		newMouse.brand = mouse.brand;
		return newMouse;
	}
}
