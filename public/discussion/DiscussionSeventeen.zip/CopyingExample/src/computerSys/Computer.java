package computerSys;

public class Computer {
	private String name;
	private Mouse mouse;

	/* Allow us to create a Computer object; why we need it? */
	public Computer() {
	}

	public Computer(String name, String mouseBrand) {
		this.name = name;
		mouse = new Mouse(mouseBrand);
	}

	public String toString() {
		return name + ", " + mouse;
	}

	public void moveMouse(int x, int y) {
		mouse.changeCoordinates(x, y);
	}
	
	public void changeName(String name) {
		this.name = name;
	}
	
	public static Computer referenceCopy(Computer computer) {
		return computer;
	}

	public static Computer deepCopy(Computer computer) {
		Computer newComputer = new Computer();
		newComputer.name = new String(computer.name);
		newComputer.mouse = Mouse.deepCopy(computer.mouse);
		return newComputer;
	}

	
	public static Computer shallowCopy(Computer computer) {
		Computer newComputer = new Computer();
		newComputer.name = computer.name;
		newComputer.mouse = computer.mouse;
		return newComputer;
	}

	
	public static Computer efficientCopy(Computer computer) {
		Computer newComputer = new Computer();
		newComputer.name = computer.name;
		newComputer.mouse = Mouse.shallowCopy(computer.mouse);
		return newComputer;
		
	}
}
