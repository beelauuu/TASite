package computerSys;

public class MouseCopyDriver {

	public static void main(String[] args) {
		Mouse first, second;

		first = new Mouse("IBM");
		first.changeCoordinates(10, 20);
		System.out.println(first);

		System.out.println("Reference copy ===================");
		first = new Mouse("Dell");
		first.changeCoordinates(100, 200);
		second = Mouse.referenceCopy(first);
		second.changeName("IBM");
		second.changeCoordinates(0, 0);
		System.out.println(first);
		System.out.println(second);

		System.out.println("\nDeep copy ===================");
		first = new Mouse("Dell");
		first.changeCoordinates(100, 200);
		second = Mouse.deepCopy(first);
		second.changeName("IBM");
		second.changeCoordinates(0, 0);
		System.out.println(first);
		System.out.println(second);

		System.out.println("\nShallow copy ===================");
		first = new Mouse("Dell");
		first.changeCoordinates(100, 200);
		second = Mouse.shallowCopy(first);
		second.changeName("IBM");
		second.changeCoordinates(0, 0);
		System.out.println(first);
		System.out.println(second);
	}
}
