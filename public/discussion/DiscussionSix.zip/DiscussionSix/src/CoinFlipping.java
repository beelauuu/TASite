import java.util.Scanner;
import java.util.Random;

public class CoinFlipping {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Random r = new Random();
		
		System.out.print("Enter in the amount of coins: ");
		int coins = input.nextInt();
		int counter = 0;
		
		//While-loop
		while(counter < coins) {
			boolean isHeads = r.nextBoolean();
			
			if(isHeads) {
				System.out.println("Heads");
			}
			else {
				System.out.println("Tails");
			}
			
			counter++;
		}
		
		//For-loop (uncomment if you want to run) 
//		for(int counter = 0; counter < coins; counter++) {
//			boolean isHeads = r.nextBoolean();
//			
//			if(isHeads) {
//				System.out.println("Heads");
//			}
//			else {
//				System.out.println("Tails");
//			}
//		}
		
		//Notice that we can format the loop from counter = 1 to <= coins for both of them :)
	}
}
